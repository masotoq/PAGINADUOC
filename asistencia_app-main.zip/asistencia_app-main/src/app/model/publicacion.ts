export class Publicacion {

	id = '';
	correo = '';
	nombre = '';
	apellido = '';
	titulo = '';
	contenido = '';

	constructor() {
	
	}

}
