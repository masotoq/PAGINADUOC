1. Para instalar json-server:

npm install -g json-server

2. Para ejecutar json-server:

json-server --watch publicaciones.json